-- phpMyAdmin SQL Dump
-- version 4.9.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 12, 2021 at 01:13 AM
-- Server version: 10.2.3-MariaDB-log
-- PHP Version: 7.2.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `titip-hewan`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id` int(11) NOT NULL,
  `kode_barang` char(20) NOT NULL,
  `nama_barang` varchar(200) NOT NULL,
  `category_id` int(11) NOT NULL,
  `satuan_id` int(11) NOT NULL,
  `min_stok` int(11) DEFAULT NULL,
  `max_stok` int(11) DEFAULT NULL,
  `harga_jual` double NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id`, `kode_barang`, `nama_barang`, `category_id`, `satuan_id`, `min_stok`, `max_stok`, `harga_jual`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'BR00001', 'Melt Sea', 2, 1, 0, 0, 300000, 1, '2021-01-22 16:55:14', '2021-02-01 06:14:21'),
(2, 'BR00002', 'Psuhome', 2, 2, 0, 0, 45000, 1, '2021-01-25 03:40:34', '2021-02-01 06:15:42'),
(3, 'BR00003', 'Samahe', 3, 3, NULL, NULL, 350000, 1, '2021-02-01 06:16:00', '2021-02-01 06:16:00');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `nama_category` varchar(200) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `nama_category`, `created_by`, `created_at`, `updated_at`) VALUES
(2, 'Makanan Kucing', NULL, '2021-01-22 03:49:06', '2021-01-30 16:20:58'),
(3, 'Makanan Anjing', NULL, '2021-01-22 04:03:05', '2021-01-30 16:21:11'),
(4, 'Aksesoris Anjing', NULL, '2021-01-22 04:51:58', '2021-01-30 16:21:25');

-- --------------------------------------------------------

--
-- Table structure for table `grooming`
--

CREATE TABLE `grooming` (
  `id` int(11) NOT NULL,
  `nama_hewan` varchar(200) NOT NULL,
  `nama_pemilik` varchar(200) NOT NULL,
  `kontak_pemilik` varchar(200) NOT NULL,
  `jenis_grooming_id` int(11) DEFAULT NULL,
  `biaya` double NOT NULL,
  `total_biaya` double NOT NULL,
  `petugas_grooming` int(11) NOT NULL,
  `tgl_grooming` date NOT NULL,
  `konsumen_id` int(11) DEFAULT NULL,
  `status` enum('panding','proses','selesai') NOT NULL DEFAULT 'selesai',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grooming`
--

INSERT INTO `grooming` (`id`, `nama_hewan`, `nama_pemilik`, `kontak_pemilik`, `jenis_grooming_id`, `biaya`, `total_biaya`, `petugas_grooming`, `tgl_grooming`, `konsumen_id`, `status`, `created_by`, `created_at`, `updated_at`) VALUES
(3, 'Unyu', 'Shofain Anshori', '083129227', 1, 55000, 55000, 2, '2021-02-01', NULL, 'selesai', 1, '2021-01-31 19:03:30', '2021-01-31 19:08:32'),
(5, 'Jebat', 'Mahzan', '32415', 1, 55000, 55000, 4, '2021-03-08', 1, 'selesai', 7, '2021-03-08 06:01:23', '2021-03-09 05:42:32');

-- --------------------------------------------------------

--
-- Table structure for table `jenis_grooming`
--

CREATE TABLE `jenis_grooming` (
  `id` int(11) NOT NULL,
  `nama_grooming` varchar(200) NOT NULL,
  `biaya_grooming` double NOT NULL,
  `keterangan` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jenis_grooming`
--

INSERT INTO `jenis_grooming` (`id`, `nama_grooming`, `biaya_grooming`, `keterangan`, `created_at`, `updated_at`) VALUES
(1, 'Paket Cantik', 55000, 'Tersedia dalam berbagai fasilitas', '2021-01-30 17:22:01', '2021-01-30 17:26:36'),
(3, 'Grooming Complet', 150000, 'Layanan Lengkap', '2021-01-30 18:17:39', '2021-01-30 18:17:39');

-- --------------------------------------------------------

--
-- Table structure for table `kartu_stok`
--

CREATE TABLE `kartu_stok` (
  `id` int(11) NOT NULL,
  `pembelian_detail_id` int(11) DEFAULT NULL,
  `penjualan_detail_id` int(11) DEFAULT NULL,
  `tgl_transaksi` datetime NOT NULL,
  `barang_id` int(11) NOT NULL,
  `qty_in` int(11) DEFAULT NULL,
  `qty_out` int(11) DEFAULT NULL,
  `hpp` double DEFAULT NULL,
  `balance` int(11) DEFAULT NULL,
  `sisa_stok` int(11) DEFAULT NULL,
  `key_index` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kartu_stok`
--

INSERT INTO `kartu_stok` (`id`, `pembelian_detail_id`, `penjualan_detail_id`, `tgl_transaksi`, `barang_id`, `qty_in`, `qty_out`, `hpp`, `balance`, `sisa_stok`, `key_index`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, '2021-01-30 00:00:00', 1, 40, NULL, 50000, 2000000, 40, 1, 1, '2021-01-30 02:14:23', '2021-01-30 02:14:23'),
(2, 2, NULL, '2021-01-30 00:00:00', 2, 40, NULL, 60000, 2400000, 40, 2, 1, '2021-01-30 02:14:23', '2021-01-30 02:14:23'),
(3, NULL, 1, '2021-01-30 00:00:00', 1, NULL, 5, 77777.77777777778, 2722222, 35, 3, 1, '2021-01-30 02:16:47', '2021-01-30 02:16:47'),
(4, NULL, 2, '2021-01-30 00:00:00', 2, NULL, 10, 57000, 1710000, 30, 4, 1, '2021-01-30 02:16:47', '2021-01-30 02:16:47'),
(5, NULL, NULL, '2021-01-30 00:00:00', 1, NULL, 5, 77777.77777777778, 2333333, 30, 5, 3, '2021-01-30 02:17:31', '2021-01-30 02:17:31'),
(6, NULL, NULL, '2021-01-30 00:00:00', 1, 5, NULL, 77777.77777777778, 388889, 5, 6, 3, '2021-01-30 02:17:31', '2021-01-30 02:17:31'),
(7, NULL, NULL, '2021-01-30 00:00:00', 2, NULL, 10, 57000, 1140000, 20, 7, 3, '2021-01-30 02:17:31', '2021-01-30 02:17:31'),
(8, NULL, NULL, '2021-01-30 00:00:00', 2, 10, NULL, 57000, 570000, 10, 8, 3, '2021-01-30 02:17:31', '2021-01-30 02:17:31'),
(9, 3, NULL, '2021-02-01 00:00:00', 1, 10, NULL, 61604.938271604944, 2772222, 45, 9, 1, '2021-01-31 19:19:02', '2021-01-31 19:19:02'),
(10, 4, NULL, '2021-02-01 00:00:00', 2, 10, NULL, 44250, 1770000, 40, 10, 1, '2021-01-31 19:19:02', '2021-01-31 19:19:02'),
(11, NULL, 4, '2021-02-01 00:00:00', 1, NULL, 10, 104949.49494949494, 3673232, 35, 11, 1, '2021-01-31 22:02:01', '2021-01-31 22:02:01'),
(12, NULL, 5, '2021-02-01 00:00:00', 2, NULL, 10, 44400, 1332000, 30, 12, 1, '2021-01-31 22:02:01', '2021-01-31 22:02:01');

-- --------------------------------------------------------

--
-- Table structure for table `konsumen`
--

CREATE TABLE `konsumen` (
  `id` int(11) NOT NULL,
  `nama` varchar(200) DEFAULT NULL,
  `alamat` varchar(200) DEFAULT NULL,
  `no_telp` char(12) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `konsumen`
--

INSERT INTO `konsumen` (`id`, `nama`, `alamat`, `no_telp`, `created_at`, `updated_at`, `user_id`) VALUES
(1, 'Konsumen 1', 'Mataram', '083129252520', '2021-03-06 00:54:07', '2021-03-06 00:54:07', 7);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran_pembelian`
--

CREATE TABLE `pembayaran_pembelian` (
  `id` int(11) NOT NULL,
  `tgl_pembayaran` datetime NOT NULL,
  `pembelian_id` int(11) NOT NULL,
  `jumlah` double NOT NULL,
  `keterangan` varchar(200) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembayaran_pembelian`
--

INSERT INTO `pembayaran_pembelian` (`id`, `tgl_pembayaran`, `pembelian_id`, `jumlah`, `keterangan`, `created_by`, `created_at`, `updated_at`) VALUES
(1, '2021-01-30 00:00:00', 1, 4400000, 'Pembayaran Awal', 1, '2021-01-30 02:14:23', '2021-01-30 02:14:23'),
(2, '2021-02-01 00:00:00', 2, 110000, 'Pembayaran Awal', 1, '2021-01-31 19:19:02', '2021-01-31 19:19:02');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran_penjualan`
--

CREATE TABLE `pembayaran_penjualan` (
  `id` int(11) NOT NULL,
  `tgl_pembayaran` datetime NOT NULL,
  `penjualan_id` int(11) NOT NULL,
  `jumlah` double NOT NULL,
  `keterangan` varchar(200) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembayaran_penjualan`
--

INSERT INTO `pembayaran_penjualan` (`id`, `tgl_pembayaran`, `penjualan_id`, `jumlah`, `keterangan`, `created_by`, `created_at`, `updated_at`) VALUES
(1, '2021-01-30 00:00:00', 1, 1950000, 'Pembayaran Awal', 1, '2021-01-30 02:16:47', '2021-01-30 02:16:47'),
(3, '2021-02-01 00:00:00', 4, 3450000, 'Pembayaran Awal', 1, '2021-01-31 22:02:01', '2021-01-31 22:02:01');

-- --------------------------------------------------------

--
-- Table structure for table `pembelian`
--

CREATE TABLE `pembelian` (
  `id` int(11) NOT NULL,
  `tgl_pembelian` datetime NOT NULL,
  `suplier_id` int(11) NOT NULL,
  `no_invoice` char(20) NOT NULL,
  `tgl_invoice` datetime NOT NULL,
  `total_invoice` double NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembelian`
--

INSERT INTO `pembelian` (`id`, `tgl_pembelian`, `suplier_id`, `no_invoice`, `tgl_invoice`, `total_invoice`, `created_by`, `created_at`, `updated_at`) VALUES
(1, '2021-01-30 00:00:00', 1, 'TK012101-0001', '2021-01-30 00:00:00', 4400000, 1, '2021-01-30 02:14:23', '2021-01-30 02:14:23'),
(2, '2021-02-01 00:00:00', 1, 'INV2102-0001', '2021-02-01 00:00:00', 110000, 1, '2021-01-31 19:19:02', '2021-01-31 19:19:02');

-- --------------------------------------------------------

--
-- Table structure for table `pembelian_detail`
--

CREATE TABLE `pembelian_detail` (
  `id` int(11) NOT NULL,
  `pembelian_id` int(11) NOT NULL,
  `barang_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` double NOT NULL,
  `sub_total` double NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembelian_detail`
--

INSERT INTO `pembelian_detail` (`id`, `pembelian_id`, `barang_id`, `qty`, `harga`, `sub_total`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 40, 50000, 2000000, '2021-01-30 02:14:23', '2021-01-30 02:14:23'),
(2, 1, 2, 40, 60000, 2400000, '2021-01-30 02:14:23', '2021-01-30 02:14:23'),
(3, 2, 1, 10, 5000, 50000, '2021-01-31 19:19:02', '2021-01-31 19:19:02'),
(4, 2, 2, 10, 6000, 60000, '2021-01-31 19:19:02', '2021-01-31 19:19:02');

-- --------------------------------------------------------

--
-- Table structure for table `penjualan`
--

CREATE TABLE `penjualan` (
  `id` int(11) NOT NULL,
  `no_invoice` char(20) NOT NULL,
  `tgl_invoice` datetime NOT NULL,
  `total_invoice` double NOT NULL,
  `keterangan` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjualan`
--

INSERT INTO `penjualan` (`id`, `no_invoice`, `tgl_invoice`, `total_invoice`, `keterangan`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'TK012101-0002', '2021-01-30 00:00:00', 1950000, 'khj', 1, '2021-01-30 02:16:47', '2021-01-30 02:16:47'),
(4, 'INV2102-0002', '2021-02-01 00:00:00', 3450000, 'ASG', 1, '2021-01-31 22:02:01', '2021-01-31 22:02:01');

-- --------------------------------------------------------

--
-- Table structure for table `penjualan_detail`
--

CREATE TABLE `penjualan_detail` (
  `id` int(11) NOT NULL,
  `penjualan_id` int(11) NOT NULL,
  `barang_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` double NOT NULL,
  `sub_total` double NOT NULL,
  `hpp` double DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjualan_detail`
--

INSERT INTO `penjualan_detail` (`id`, `penjualan_id`, `barang_id`, `qty`, `harga`, `sub_total`, `hpp`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 5, 300000, 1500000, 77777.77777777778, '2021-01-30 02:16:47', '2021-01-30 02:16:47'),
(2, 1, 2, 10, 45000, 450000, 57000, '2021-01-30 02:16:47', '2021-01-30 02:16:47'),
(4, 4, 1, 10, 300000, 3000000, 104949.49494949494, '2021-01-31 22:02:01', '2021-01-31 22:02:01'),
(5, 4, 2, 10, 45000, 450000, 44400, '2021-01-31 22:02:01', '2021-01-31 22:02:01');

-- --------------------------------------------------------

--
-- Table structure for table `satuan`
--

CREATE TABLE `satuan` (
  `id` int(11) NOT NULL,
  `nama_satuan` varchar(200) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `satuan`
--

INSERT INTO `satuan` (`id`, `nama_satuan`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'Karung', 1, '2021-01-22 04:53:37', '2021-01-22 04:53:37'),
(2, 'Kilo', 1, '2021-01-22 04:54:14', '2021-01-22 04:54:14'),
(3, 'Botol', 1, '2021-01-25 03:39:36', '2021-01-25 03:39:36');

-- --------------------------------------------------------

--
-- Table structure for table `suplier`
--

CREATE TABLE `suplier` (
  `id` int(11) NOT NULL,
  `kode_suplier` char(20) NOT NULL,
  `nama_suplier` varchar(200) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `no_telp` char(20) NOT NULL,
  `fax` char(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suplier`
--

INSERT INTO `suplier` (`id`, `kode_suplier`, `nama_suplier`, `alamat`, `no_telp`, `fax`, `email`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'SP0001', 'Shofian Anshori', 'Jl. Gora no 1 selagalas', '083129252520', '12345', 'anshorishofian.sa@gmail.com', 1, '2021-01-22 05:15:34', '2021-01-22 05:15:34'),
(3, 'SP0002', 'Zayyan Anshori', 'Mataram', '098321', '123456789', 'vhyan@gmail.com', 1, '2021-01-22 05:17:49', '2021-01-22 05:22:16');

-- --------------------------------------------------------

--
-- Table structure for table `titip_sehat`
--

CREATE TABLE `titip_sehat` (
  `id` int(11) NOT NULL,
  `konsumen_id` int(11) DEFAULT NULL,
  `nama_hewan` varchar(200) DEFAULT NULL,
  `tgl_mulai_titip` date NOT NULL,
  `tgl_selesai_titip` date NOT NULL,
  `alergi` enum('0','1') NOT NULL DEFAULT '0',
  `keterangan` text DEFAULT NULL,
  `nama_makanan` text DEFAULT NULL,
  `nama_pemilik` varchar(200) DEFAULT NULL,
  `kontak_pemilik` char(20) DEFAULT NULL,
  `biaya_per_hari` double DEFAULT NULL,
  `total_biaya` double DEFAULT NULL,
  `status` enum('panding','proses','selesai') NOT NULL DEFAULT 'selesai',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `titip_sehat`
--

INSERT INTO `titip_sehat` (`id`, `konsumen_id`, `nama_hewan`, `tgl_mulai_titip`, `tgl_selesai_titip`, `alergi`, `keterangan`, `nama_makanan`, `nama_pemilik`, `kontak_pemilik`, `biaya_per_hari`, `total_biaya`, `status`, `created_by`, `created_at`, `updated_at`) VALUES
(2, NULL, 'Push', '2021-01-31', '2021-02-01', '0', 'Beri maka sebelum sore', 'Otak Pindang', 'Shofian', '083129252520', 200000, 400000, 'selesai', 1, '2021-01-31 00:25:36', '2021-01-31 00:25:36'),
(3, 1, 'Jebat', '2021-03-09', '2021-03-11', '0', 'Mohon di proses segera', 'Makanan ikan laut', 'Vhyan', '21423', 200000, 600000, 'selesai', 7, '2021-03-09 04:42:41', '2021-03-09 05:30:05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_telp` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('admin','petugas','owner','konsumen') COLLATE utf8mb4_unicode_ci DEFAULT 'petugas',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `alamat`, `no_telp`, `email_verified_at`, `password`, `remember_token`, `role`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', 'admin@gmail.com', 'Kota mataram', '083129252520', NULL, '$2y$10$vJ8D.C/ZkMaO1idGTC6KJ.OaQyIpOxESCq9yv7798yzqAs9NuHWEG', NULL, 'admin', NULL, '2021-01-23 16:25:35'),
(2, 'Shofian Anshori', 'vhyan@gmail.com', 'Jl. Gora no 1, Selagalas kota mataram', '083129252520', NULL, '$2y$10$.zsniBid7xiAoTQEl8PhK.urYmRjxaDFtNt97oyjF4sTiOgd9/IcO', NULL, 'admin', '2021-01-23 15:54:23', '2021-01-23 16:24:58'),
(3, 'Zayyan', 'zayyan@gmail.com', 'mataram', '099805435345', NULL, '$2y$10$TSdetvWZlMlh7MYDvFCMkuulcffcM/jrvjuPZGyUG/VNEclKr4IbS', NULL, 'admin', '2021-01-29 06:08:59', '2021-03-11 17:00:37'),
(4, 'Petugas', 'petugas@gmail.com', 'Mataram', '08312926252', NULL, '$2y$10$DApFFvlcb6yseeSovIAaLe41FEB5omT.r9rzN9Pl8vHST3XsM38.S', NULL, 'petugas', '2021-01-31 23:02:17', '2021-01-31 23:02:17'),
(5, 'Pemilik', 'pemilik@gmail.com', 'Mataram', '0831292525789', NULL, '$2y$10$wqGfIGw.ACi83XIvKg0wxuY31IrCQ3nfAx0QnS8TpdIzCB/fZKOCi', NULL, 'owner', '2021-01-31 23:02:58', '2021-01-31 23:02:58'),
(7, 'Konsumen 1', 'konsumen@gmail.com', 'Mataram', '083129252520', NULL, '$2y$10$n8Y5T15k0v3SRdXBKcXhuOF2Wc1Oq1m4e/UeUpbwpmrm9KqhjtQt2', NULL, 'konsumen', '2021-03-06 00:54:06', '2021-03-06 00:54:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `grooming`
--
ALTER TABLE `grooming`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jenis_grooming`
--
ALTER TABLE `jenis_grooming`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kartu_stok`
--
ALTER TABLE `kartu_stok`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key_index` (`key_index`),
  ADD KEY `key_index_2` (`key_index`);

--
-- Indexes for table `konsumen`
--
ALTER TABLE `konsumen`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `pembayaran_pembelian`
--
ALTER TABLE `pembayaran_pembelian`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pembayaran_penjualan`
--
ALTER TABLE `pembayaran_penjualan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pembelian`
--
ALTER TABLE `pembelian`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pembelian_detail`
--
ALTER TABLE `pembelian_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `penjualan_detail`
--
ALTER TABLE `penjualan_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `satuan`
--
ALTER TABLE `satuan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suplier`
--
ALTER TABLE `suplier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `titip_sehat`
--
ALTER TABLE `titip_sehat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `grooming`
--
ALTER TABLE `grooming`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `jenis_grooming`
--
ALTER TABLE `jenis_grooming`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `kartu_stok`
--
ALTER TABLE `kartu_stok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `konsumen`
--
ALTER TABLE `konsumen`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pembayaran_pembelian`
--
ALTER TABLE `pembayaran_pembelian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pembayaran_penjualan`
--
ALTER TABLE `pembayaran_penjualan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pembelian`
--
ALTER TABLE `pembelian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pembelian_detail`
--
ALTER TABLE `pembelian_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `penjualan`
--
ALTER TABLE `penjualan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `penjualan_detail`
--
ALTER TABLE `penjualan_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `satuan`
--
ALTER TABLE `satuan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `suplier`
--
ALTER TABLE `suplier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `titip_sehat`
--
ALTER TABLE `titip_sehat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
